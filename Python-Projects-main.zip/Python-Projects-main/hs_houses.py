from turtle import *
import math

# Upravte vložený kód tak, aby program vykreslil takovou střechu, s nastavitelnou délkou podstavy.

def domecek(x,y,barva):
    pencolor(barva)
    fillcolor(barva)
    pu()
    setpos(x,y)
    pd()
    begin_fill()
    fd(delka_strany)
    rt(90)
    fd(delka_strany)
    rt(90)
    fd(delka_strany)
    rt(90)
    fd(delka_strany)
    rt(90)
    lt(math.degrees(math.atan(vyska_strechy /(delka_strany/2))))
    fd(math.sqrt((delka_strany/2)**2 + vyska_strechy**2))
    rt(2*math.degrees(math.atan(vyska_strechy /(delka_strany/2))))
    fd(math.sqrt((delka_strany/2)**2 + vyska_strechy**2))
    setheading(0)
    end_fill()

speed(10)
delka_strany=200
mezera=30
pensize(10)
vyska_strechy=120

domecek(-delka_strany-mezera, delka_strany+mezera,"red")
domecek(mezera, delka_strany+mezera,"lightgreen")
domecek(mezera, -mezera*4,"yellow")
domecek(-mezera-delka_strany, -mezera*4,"blue")
