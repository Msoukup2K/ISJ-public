from turtle import *
from random import randint


# S využitím mnou vloženého kódu (poslední vložený soubor na zdi) kreslení kostek jej upravte tak, 
# aby dle zvolené velikosti kostky program nakreslil 6 kostek, 
# aby vlezly do standardně velké želví plochy buď jako 6 kostek vedle sebe, 
# nebo dvě řady po třech kostkách 
# nebo tři řady po dvou kostkách. 
# Byl bych rád (jinak řečeno - máte prozatím ve vlastním zájmu zakázáno), kdybyste při řešení úloh nevyužívali AI, 
# protože je v první fázi nutné, abyste se naučili psát programy s pomocí vlastního myšlení.


def tecka():
    pd()
    fd(0)
    pu()

def kostka(x,y,velikostkostky):
    pu()
    setpos(x,y)
    pd()
    for _ in range(4):
        fd(velikostkostky)
        rt(90)


def stranakostky(x,y,velikostkostky,cislo):
    #pozice tecek na kostce
    #1 4 7
    #2 5 8
    #3 6 9
    pu()
    pensize(velikostkostky/6)
    setpos(x,y)
    ctvrtina = int(velikostkostky/4)
    #if (cislo==2) or (cislo==3) or (cislo==4) or (cislo==5) or (cislo==6):
    if cislo in [2,4,5,6]:#1
        setpos(x+ctvrtina,y-ctvrtina)
        tecka()
    if cislo in [6]:#2
        setpos(x+ctvrtina,y-2ctvrtina)
        tecka()
    if cislo in [3,4,5,6]:#3
        setpos(x+ctvrtina,y-3ctvrtina)
        tecka()
    if cislo in [1,3,5]:#5
        setpos(x+2ctvrtina,y-2ctvrtina)
        tecka()
    if cislo in [3,4,5,6]:#7
        setpos(x+3ctvrtina,y-ctvrtina)
        tecka()
    if cislo in [6]:#8
        setpos(x+3ctvrtina,y-2ctvrtina)
        tecka()
    if cislo in [2,4,5,6]:#9
        setpos(x+3ctvrtina,y-3*ctvrtina)
        tecka()
    pensize(velikostkostky/30)

velikostkostky = 100
x=-400
y=200
mezera = velikostkostky/6
pensize(velikostkostky/30)

for k in range(6):
    kostka(x,y,velikostkostky)
    stranakostky(x,y,velikostkostky,k+1)
    x = x + velikostkostky + mezera